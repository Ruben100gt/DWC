'use strict';

//Ejercicio1

import { mesNumero } from './biblioteca/ejercicio1.js';
mesNumero(7);

//Ejercicio2
import { analisisNumerico } from './biblioteca/ejercicio2.js';
analisisNumerico(6);

//Ejercicio3
import { multiplosDeTres } from './biblioteca/ejercicio3.js';
multiplosDeTres(21);

//Ejercicio4
import { potencia } from './biblioteca/ejercicio4.js';
potencia(2, 0);
potencia(2, 7);

//Ejercicio5
import { mediaNumeros } from './biblioteca/ejercicio5.js';
mediaNumeros(31, 0, 12);
mediaNumeros(0, 60, 120);

//Ejercicio6
import { calculadora } from './biblioteca/ejercicio6.js';
calculadora(1, 5, '+');
calculadora(4, 1, '-');
calculadora(12, 3, '*');
calculadora(560, 20, '/');
calculadora(15, 3, '%');
