import React from 'react';

const AcercaDe = () => {
	return (
		<>
			<h2>Acerca de esta aplicación:</h2>
			<p>Versión: 1.9.0</p>
			<p>Desarrollado por: Rubén</p>
			<p>Última modificación: Octubre 2025</p>
		</>
	);
};

export default AcercaDe;
