import React from 'react';

const Cabecera = () => {
	return (
		<>
			<h1>Gestión de Películas.</h1>
		</>
	);
};

export default Cabecera;
