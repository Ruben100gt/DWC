import React from "react";

const Pie = () => {
	return (
		<>
			<p>Aplicación de colección de discos.</p>
		</>
	);
};

export default Pie;
