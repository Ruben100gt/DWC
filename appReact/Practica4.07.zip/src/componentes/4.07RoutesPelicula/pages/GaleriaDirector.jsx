import React from "react";

const GaleriaDirector = () => {
	return (
		<>
			<h2>Aquí se mostraría la galería filtrada por director.</h2>
		</>
	);
};

export default GaleriaDirector;
