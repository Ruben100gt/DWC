import React from 'react';

const Cargando = () => {
	return (
		<div>
			<h2>Cargando discos...</h2>
			<p>Por favor, espera un momento.</p>
		</div>
	);
};

export default Cargando;
