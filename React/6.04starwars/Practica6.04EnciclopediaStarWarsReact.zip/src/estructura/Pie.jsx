import React from 'react';
import './Pie.css';

const Pie = () => {
	return <footer>Aplicación de listado de películas de StarWars.</footer>;
};

export default Pie;
