import React from "react";

const GaleriaTitulo = () => {
	return (
		<>
			<h2>Aquí se mostraría la galería filtrada por título.</h2>
		</>
	);
};

export default GaleriaTitulo;
