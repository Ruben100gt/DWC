import React from "react";
import "./Pie.css";

const Pie = () => {
	return (
		<footer>
			<p>Aplicación de lista de la compra con Supabase.</p>
		</footer>
	);
};

export default Pie;
