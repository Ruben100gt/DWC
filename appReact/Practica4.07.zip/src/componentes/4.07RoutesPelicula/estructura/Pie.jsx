import React from 'react';

const Pie = () => {
	return (
		<>
			<p>Aplicación de gestión de películas.</p>
		</>
	);
};

export default Pie;
