import React from "react";

const GaleriaInterprete = () => {
	return (
		<>
			<h2>Aquí se mostraría la galería filtrada por intérprete.</h2>
		</>
	);
};

export default GaleriaInterprete;
